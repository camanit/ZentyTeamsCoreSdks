﻿================================================================================
   ZENTYTEAMSCORE — SOVEREIGN COMMUNITY EVALUATION EDITION (v0.1.0)
   Indonesian Sovereign Cybersecurity Orchestrator & Multi-Tenant Defense
================================================================================

PETUNJUK PENGGUNAAN CEPAT:
1. Ekstrak dan jalankan 'ZentyTeamsCore.exe'.
2. Aplikasi akan terbuka secara mandiri (Portable, tanpa perlu instalasi rumit).
3. Status bawaan: 'COMMUNITY EVALUATION (FREE)'.
   - Modul Terbuka: Blue Team (Deteksi, Pertahanan Siber, dan Inspeksi RASP).
   - Modul Terkunci: Mission Control, Red Team, Dark Intel, dan SuperAdmin
     (Khusus lisensi Enterprise / Sovereign / Militer).

CARA AKTIVASI KE TIER ENTERPRISE / SOVEREIGN:
1. Buka menu 'Pengaturan' atau 'Profil & Keamanan' di dalam aplikasi.
2. Salin 'Machine ID' unik perangkat PC Anda.
3. Hubungi Administrator / CSIRT CTARTech untuk mendapatkan lisensi resmi.
4. Baca berkas 'PANDUAN_AKTIVASI.txt' untuk panduan lengkap aktivasi.

Kontak Resmi & Dukungan:
- Web: https://zentyteamscore.ctar.tech
- GitHub: https://github.com/camanit/ZentyTeamsCoreSdks
- Email: enterprise@ctar.tech
================================================================================
